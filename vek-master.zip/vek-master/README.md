# Avaliação VEK

 A simple boilerplate to jumpstart the development of simple static sites.

## Instalação

Para instalar as dependencias é necessario exercutar o comando na pasta raiz do front-end e do back-end.

    > npm install

## Compilação e transpilação - Front-End

Rodar os seguintes comandos executam a "compilação" do css e a transpilação do javascript no modo watch.

    > npm run compile:sass
    > npm run transpile:js

## Execução do Back-end

Para executar o backend, é necessário utilizar o comando a seguir na pasta raiz do back-end.

    > node index.js

Também é preciso executar o script da pasta raiz do projeto num ambiente mysql e criar o usuario vek com a senha vek.